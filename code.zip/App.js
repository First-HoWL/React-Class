import logo from './logo.svg';
import './App.css';
import { useState, useEffect } from 'react';

function App() {

  const [meowFact, setMeowFact] = useState();
  function getMeowFact(){
    fetch("https://meowfacts.herokuapp.com/")
    .then((response) => response.json())
    .then((fact)=>{
      console.log(fact['data']);
      setMeowFact(fact['data'])
    })
  }

  useEffect(() => {
    getMeowFact()
  }, [])
  

  return (
    <>
    <div className='genDiv'>
      <div className='divBox'>
        <p onClick={(e)=>{getMeowFact()}}>{meowFact}</p>
      </div>
    </div>
    </>
  );
}

export default App;
